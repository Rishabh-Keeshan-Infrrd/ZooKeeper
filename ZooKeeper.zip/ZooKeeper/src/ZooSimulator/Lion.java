package ZooSimulator;

public class Lion extends Animal{
    public void sound(){
        System.out.println("The Lion roars!");
    }

    public void eat(){
        System.out.println("Lion is eating!");
    }
}
