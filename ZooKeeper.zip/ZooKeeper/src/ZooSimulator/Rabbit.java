package ZooSimulator;

public class Rabbit extends Animal {
    public void sound(){
        System.out.println("The Rabbit mutters!");
    }

    public void eat() {
        System.out.println("Rabbit is eating!");
    }
}
