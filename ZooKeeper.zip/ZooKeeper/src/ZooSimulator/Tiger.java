package ZooSimulator;

public class Tiger extends Animal{
    public void sound(){
        System.out.println("The Tiger roars!");
    }

    public void eat(){
        System.out.println("Tiger is eating!");
    }
}
