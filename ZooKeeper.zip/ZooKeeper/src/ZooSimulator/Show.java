package ZooSimulator;

public class Show {

        public void showTime(Animal[] animals){
            for (Animal animal : animals) {
                animal.sound();
            }
        }


}
