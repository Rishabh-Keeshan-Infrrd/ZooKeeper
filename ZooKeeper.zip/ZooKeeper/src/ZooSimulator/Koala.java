package ZooSimulator;

public class Koala extends Animal{
    public void sound(){
        System.out.println("The Koala squeaks!");
    }

    public void eat(){
        System.out.println("Koala is eating");
    }
}
