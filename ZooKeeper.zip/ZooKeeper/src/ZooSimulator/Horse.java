package ZooSimulator;

public class Horse extends Animal{
    public void sound(){
        System.out.println("The Horse neighs!");
    }

    public void eat(){
        System.out.println("Horse is eating");
    }
}
