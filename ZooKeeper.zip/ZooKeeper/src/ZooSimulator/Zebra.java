package ZooSimulator;

public class Zebra extends Animal{
    public void sound(){
        System.out.println("The Zebra barks!");
    }

    public void eat(){
        System.out.println("Zebra is eating!");
    }
}
