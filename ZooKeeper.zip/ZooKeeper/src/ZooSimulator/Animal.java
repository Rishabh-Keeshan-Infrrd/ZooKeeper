package ZooSimulator;

public class Animal {

    public void sound(){

        System.out.println("Animal makes sound");
    }

    public void eat(){
        System.out.println("Animal Eats");
    }
}
